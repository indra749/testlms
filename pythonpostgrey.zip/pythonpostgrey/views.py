from flask import render_template, redirect, url_for, flash
from app import app, db
from app import User, LoginForm

@app.route('/', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        
        # Query the database for the user
        user = User.query.filter_by(username=username, password=password).first()
        
        if user:
            # If user is found, login is successful
            flash('Login Successful', 'success')  # Add flash message for successful login
            return redirect(url_for('home'))  # Redirect to a different route (e.g., home)
        else:
            # If user is not found, show an error message
            flash('Login Unsuccessful. Please check your username and password', 'danger')
    
    return render_template('login.html', form=form)

@app.route('/home')
def home():
    return 'Welcome to the Home Page!'  # Replace this with the actual home page template
